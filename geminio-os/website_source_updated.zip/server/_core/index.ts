import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { runAiWorkerOnce } from "../ai-core/orchestrator";

function isTrustedOrigin(origin: string): boolean {
  const configuredOrigins = (process.env.CORS_ALLOWED_ORIGINS ?? "").split(",").map((value) => value.trim()).filter(Boolean);
  if (configuredOrigins.includes(origin)) return true;
  try {
    const url = new URL(origin);
    const isLocalDevelopment = url.hostname === "localhost" || url.hostname === "127.0.0.1";
    const isManusPreview = url.protocol === "https:" && (url.hostname.endsWith(".manus.computer") || url.hostname.endsWith(".manus.space"));
    return isLocalDevelopment || isManusPreview;
  } catch {
    return false;
  }
}

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Permit credentialed cross-origin requests only from configured, local, or managed preview origins.
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && isTrustedOrigin(origin)) {
      res.header("Access-Control-Allow-Origin", origin);
      res.header("Vary", "Origin");
    } else if (origin) {
      res.status(403).json({ ok: false, error: "Cross-origin request is not allowed." });
      return;
    }
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization",
    );
    res.header("Access-Control-Allow-Credentials", "true");

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`[api] server listening on port ${port}`);
    let workerTickInProgress = false;
    const runWorkerTick = async () => {
      if (workerTickInProgress) return;
      workerTickInProgress = true;
      try {
        await runAiWorkerOnce();
      } catch (error) {
        console.error("[ai-core] worker tick failed", error);
      } finally {
        workerTickInProgress = false;
      }
    };
    void runWorkerTick();
    const workerTimer = setInterval(() => { void runWorkerTick(); }, 5000);
    void workerTimer;
  });
}

startServer().catch(console.error);
